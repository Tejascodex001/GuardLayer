# GuardLayer — Log Fixes

## What the logs showed

### ✅ Working fine
- sentence-transformers/all-MiniLM-L6-v2 loaded OK
- Attack corpus: 21 injection + 21 jailbreak vectors encoded
- Ollama detected with qwen2.5:7b-instruct (real LLM active)
- 5 POST /chat requests served successfully
- NVML warning about CUDA → harmless, just means no GPU detected, runs fine on CPU

---

## Fix 1 — Toxicity classifier 401 error

### Cause
Wrong model ID in the code. We used `martin-ha/toxic-comment-classifier`
but the correct public HuggingFace model ID is `martin-ha/toxic-comment-model`
(the "classifier" variant was either renamed or never public).

### What was already fixed in the code
`config/model_loader.py` and `guards/toxicity.py` have both been updated
to use the correct model ID `martin-ha/toxic-comment-model`.

### To apply on your machine
The files in `guardlayer_v2/` already have the correct model name.
Just restart the server — it will download the correct model on first run:

```bash
python main.py
```

If you want to pre-download it before starting:
```bash
python -c "from transformers import pipeline; pipeline('text-classification', model='martin-ha/toxic-comment-model')"
```

---

## Fix 2 — spaCy en_core_web_sm not found

### Cause
spaCy is installed but the English model hasn't been downloaded yet.

### Fix — run this one command
```bash
python -m spacy download en_core_web_sm
```

That's it. Restart the server after.

---

## Expected log output after both fixes

```
GuardLayer starting up — loading ML models...
Loading sentence-transformers/all-MiniLM-L6-v2 ...
sentence-transformers loaded ✓
Loading martin-ha/toxic-comment-model ...
toxic-comment-model loaded ✓              ← now works
spaCy NER loaded ✓                        ← now works
Attack corpus encoded: 21 injection + 21 jailbreak vectors
✅ ML models loaded: ['semantic_similarity', 'toxicity_classifier', 'spacy_ner']
Model status: {'semantic_similarity': True, 'toxicity_classifier': True, 'spacy_ner': True}
Application startup complete.
```

All 3 ML models active = full production mode, no heuristic fallback needed.

---

## Summary of your current system status

| Component              | Status         | Notes                                  |
|------------------------|----------------|----------------------------------------|
| sentence-transformers  | ✅ Working      | Guards 1 + 2 using real ML             |
| DistilBERT toxicity    | ⚠️ Wrong name   | Fix: restart with updated model_loader |
| spaCy NER              | ⚠️ Not downloaded | Fix: python -m spacy download en_core_web_sm |
| Ollama LLM             | ✅ Working      | qwen2.5:7b-instruct detected           |
| NVML/CUDA warning      | ✅ Ignore       | Harmless — CPU mode works fine         |
